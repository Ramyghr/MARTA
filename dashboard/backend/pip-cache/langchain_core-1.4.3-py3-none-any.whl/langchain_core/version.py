"""Version information for `langchain-core`."""

VERSION = "1.4.3"
